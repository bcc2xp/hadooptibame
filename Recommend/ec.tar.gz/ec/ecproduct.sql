insert into webapp_ecproduct(productid, description) values(101, "ASUS X550JD");
insert into webapp_ecproduct(productid, description) values(102, "Toshiba Satellite L50");
insert into webapp_ecproduct(productid, description) values(103, "Acer VN7");
insert into webapp_ecproduct(productid, description) values(104, "ASUS T100");
insert into webapp_ecproduct(productid, description) values(105, "HP r010TX");
insert into webapp_ecproduct(productid, description) values(106, "MSI CX70");
insert into webapp_ecproduct(productid, description) values(107, "CJSCOPE QX350");
